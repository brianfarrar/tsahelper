===========
TSA Helper
===========

TSA Helper provides a number of functions that are useful for preprocessing 
HD-AIT images provided by TSA for the Kaggle Passenger Screening Contest.  
Typical usage looks like:

    #!/usr/bin/env python

    import tsahelper as tsa

Detailed example usage is also available at:

https://www.kaggle.com/jbfarrar/exploratory-data-analysis-and-example-generation
